#ifndef GSV_VECTOR3D_HH
#define GSV_VECTOR3D_HH


#include "geomVector.hh"


namespace gsv {


  typedef geom::Vector<double,3>   Vector3d;

}



#endif
