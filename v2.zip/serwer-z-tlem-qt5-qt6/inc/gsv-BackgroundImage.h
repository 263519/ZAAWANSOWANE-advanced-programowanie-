#ifndef GSV_BACKGROUNDIMAGE_H
#define GSV_BACKGROUNDIMAGE_H


#define FILE_BACKGROUND_IMAGE "./background.png"

#endif
