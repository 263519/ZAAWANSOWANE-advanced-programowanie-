#ifndef CONFIGURATION_HH
#define CONFIGURATION_HH



class Configuration {
  //...
};


#endif
